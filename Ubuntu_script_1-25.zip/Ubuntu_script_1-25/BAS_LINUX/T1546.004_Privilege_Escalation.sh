#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Privilege_Escalation"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1546.004_Privilege_Escalation.txt"

# Function to check and install required packages
function check_install_packages {
    local packages=(git curl wget)  # Example packages to check/install

    echo "Checking and installing required packages..." | tee -a "$output_file"
    for pkg in "${packages[@]}"; do
        if ! command -v "$pkg" &> /dev/null; then
            echo "  - Installing $pkg..." | tee -a "$output_file"
            if ! sudo apt-get install -y "$pkg"; then
                echo "    Failed to install $pkg. Exiting." | tee -a "$output_file"
                exit 1
            fi
        else
            echo "  - $pkg is already installed." | tee -a "$output_file"
        fi
    done
    echo "Required packages checked and installed." | tee -a "$output_file"
    echo "" | tee -a "$output_file"
}

# Function to add command to .bash_profile
function add_to_bash_profile {
    local command_to_add='echo "Hello from SISA T1546.004" > /tmp/T1546.004'
    echo "$command_to_add" >> ~/.bash_profile
    echo "  - Command added to .bash_profile" | tee -a "$output_file"
}

# Function to add command to .bashrc
function add_to_bashrc {
    local command_to_add='echo "Hello from SISA T1546.004" > /tmp/T1546.004'
    echo "$command_to_add" >> ~/.bashrc
    echo "  - Command added to .bashrc" | tee -a "$output_file"
}

# Function to add command to .shrc (Linux specific)
function add_to_shrc {
    local command_to_add='echo "Hello from SISA T1546.004" > /tmp/T1546.004'
    echo "$command_to_add" >> ~/.shrc
    echo "  - Command added to .shrc" | tee -a "$output_file"
}

# Function to append to the system shell profile
function append_to_system_profile {
    local text_to_append='# Hello from SISA T1546.004'
    echo "$text_to_append" | sudo tee -a /etc/profile > /dev/null
    echo "  - Text appended to /etc/profile" | tee -a "$output_file"
}

# Function to append commands to user shell profile
function append_to_user_profile {
    local text_to_append='# SISA was here... T1546.004'
    echo "$text_to_append" >> ~/.profile
    echo "  - Text appended to ~/.profile" | tee -a "$output_file"
}

# Function to append commands to system shell profile scripts
function append_to_system_profile_scripts {
    local text_to_append='# SISA was here... T1546.004'
    echo "$text_to_append" | sudo tee -a /etc/profile.d/bash_completion.sh > /dev/null
    echo "  - Text appended to /etc/profile.d/bash_completion.sh" | tee -a "$output_file"
}

# Function to create/append to .bash_logout
function create_append_bash_logout {
    local command_to_add='echo "SISA was here... T1546.004" >> $HOME/art.txt'
    sudo useradd --create-home --shell /bin/bash art
    sudo su -c "echo '$command_to_add' >> /home/art/.bash_logout" art
    echo "  - Command added to /home/art/.bash_logout" | tee -a "$output_file"
}

# Cleanup function for all tests
function cleanup {
    sed -i "/# SISA was here... T1546.004/d" ~/.bash_profile
    sed -i "/# SISA was here... T1546.004/d" ~/.bashrc
    sed -i "/# SISA was here... T1546.004/d" ~/.shrc
    sudo sed -i "/# Hello from SISA T1546.004/d" /etc/profile
    sudo sed -i "/# SISA was here... T1546.004/d" /etc/profile.d/bash_completion.sh
    sudo userdel -fr art
    echo "Cleanup completed." | tee -a "$output_file"
}

# Main script logic to execute chosen SISA tests
{
    echo "=========================================================="
    echo "           Executing Chosen SISA Tests (T1546.004)      "
    echo "==========================================================" | tee -a "$output_file"

    check_install_packages
    echo "" | tee -a "$output_file"

    echo "Adding commands to various profiles and shell scripts..." | tee -a "$output_file"
    add_to_bash_profile
    add_to_bashrc
    add_to_shrc
    append_to_system_profile
    append_to_user_profile
    append_to_system_profile_scripts
    create_append_bash_logout
    echo "Commands added successfully." | tee -a "$output_file"

    echo "=========================================================="
    echo "         All Chosen SISA Tests Executed Successfully    "
    echo "==========================================================" | tee -a "$output_file"
    
    # Uncomment the following line to run cleanup after tests
    # cleanup

} | tee -a "$output_file"

echo "Execution completed. Output saved to $output_file"
