#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Privilege_Escalation"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1098.004_Privilege_Escalation.txt"

# Function to perform SISA Test #1 - Modify SSH Authorized Keys
function modify_ssh_authorized_keys {
    local user_home="$1"
    local ssh_dir="$user_home/.ssh"
    local authorized_keys_file="$ssh_dir/authorized_keys"

    echo "Starting SISA Test #1: Modify SSH Authorized Keys" | tee -a "$output_file"

    # Check if the .ssh directory exists, if not, create it
    if [ ! -d "$ssh_dir" ]; then
        mkdir -p "$ssh_dir"
        echo "Created directory: $ssh_dir" | tee -a "$output_file"
    else
        echo "Directory already exists: $ssh_dir" | tee -a "$output_file"
    fi

    # Check if the authorized_keys file exists, if not, create it
    if [ ! -f "$authorized_keys_file" ]; then
        touch "$authorized_keys_file"
        echo "Created file: $authorized_keys_file" | tee -a "$output_file"
    else
        echo "File already exists: $authorized_keys_file" | tee -a "$output_file"
    fi

    # Modify the authorized_keys file
    if [ -f "$authorized_keys_file" ]; then
        ssh_authorized_keys=$(cat "$authorized_keys_file")
        echo "$ssh_authorized_keys" > "$authorized_keys_file"
        echo "SSH authorized_keys file modified successfully." | tee -a "$output_file"
    else
        echo "Error: $authorized_keys_file not found." | tee -a "$output_file"
    fi
}

# Main script logic to execute the SISA test
{
    echo "=========================================================="
    echo "               Executing Chosen SISA Test                 "
    echo "=========================================================="

    # Modify the following path to the home directory of the user you want to target
    target_user_home="/home/kali"
    modify_ssh_authorized_keys "$target_user_home"

    echo "=========================================================="
    echo "            All Chosen SISA Tests Executed                "
    echo "=========================================================="
} | tee -a "$output_file"

echo "Execution completed. Output saved to $output_file"
