#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Privilege_Escalation"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1078.003_Privilege_Escalation.sh.txt"

# Function to create local account (Linux)
create_local_account() {
    local username="art"
    local password=$(openssl passwd -1 art)
    
    # Check if user 'art' already exists
    if id "$username" &>/dev/null; then
        echo "User 'art' already exists. Skipping creation."
    else
        # Create the user 'art' with /bin/bash shell and home directory
        if [ "$(uname)" = 'Linux' ]; then
            useradd --shell /bin/bash --create-home --password $password $username
        elif [ "$(uname)" = 'FreeBSD' ]; then
            pw useradd $username -g wheel -s /bin/sh
            echo $password | pw mod user $username -h 0
        else
            echo "Unsupported platform $(uname)"
            return 1
        fi
    fi
    
    # Switch to user 'art', execute whoami, and exit
    su $username -c "whoami; exit"
    
    # Cleanup: Delete user 'art'
    if [ "$(uname)" = 'Linux' ]; then
        userdel $username -rf
    elif [ "$(uname)" = 'FreeBSD' ]; then
        rmuser -y $username
    fi
}

# Function to reactivate a locked/expired account (Linux)
reactivate_account() {
    local username="art"
    local password=$(openssl passwd -1 art)
    
    # Create the user 'art' if it does not exist
    if ! id "$username" &>/dev/null; then
        if [ "$(uname)" = 'Linux' ]; then
            useradd --shell /bin/bash --create-home --password $password $username
        elif [ "$(uname)" = 'FreeBSD' ]; then
            pw useradd $username -g wheel -s /bin/sh
            echo $password | pw mod user $username -h 0
        else
            echo "Unsupported platform $(uname)"
            return 1
        fi
    fi
    
    # Lock and expire the account, then unlock and renew it
    usermod --lock $username
    usermod --expiredate "1" $username
    usermod --unlock $username
    usermod --expiredate "99999" $username
    
    # Switch to user 'art', execute whoami, and exit
    su $username -c "whoami; exit"
    
    # Cleanup: Delete user 'art'
    userdel -r $username
}

# Function to login as nobody (Linux)
login_as_nobody() {
    local username="nobody"
    local password=$(openssl passwd -1 nobody)
    
    # Change login shell of 'nobody' to /bin/bash
    chsh --shell /bin/bash $username
    
    # Change password of 'nobody' to 'nobody'
    usermod --password $password $username
    
    # Switch to user 'nobody', execute whoami, and exit
    su $username -c "whoami; exit"
    
    # Reset 'nobody' shell to /usr/sbin/nologin
    chsh --shell /usr/sbin/nologin $username
}

# Main script execution
{
    echo "Running SISA Test - T1078.003 #8 - Create local account (Linux)"
    create_local_account

    echo "Running SISA Test - T1078.003 #9 - Reactivate a locked/expired account (Linux)"
    reactivate_account

    echo "Running SISA Test - T1078.003 #11 - Login as nobody (Linux)"
    login_as_nobody

    echo "Tests completed."
} | tee "$output_file"

echo "Execution completed. Output saved to $output_file"
