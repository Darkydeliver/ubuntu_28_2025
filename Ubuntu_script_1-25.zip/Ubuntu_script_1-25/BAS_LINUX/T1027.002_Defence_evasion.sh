#!/bin/bash

# Function to create a simple binary script and pack it with UPX
create_and_pack_binary() {
    local bin_path="$1"
    local magic_number="$2"
    local output_path="/tmp/packed_bin"
    local output_dir="./Linux_output/Defence_Evasion"
    local output_file="$output_dir/T1027.002_output.txt"

    # Ensure the output directory exists
    mkdir -p "$output_dir"

    # Create a simple binary script
    echo '#!/bin/bash' > "$bin_path"
    echo 'echo "the cake is a lie"' >> "$bin_path"

    # Add 10 more lines after "the cake is a lie"
    for (( i=1; i<=10; i++ )); do
        echo "echo \"line $i\"" >> "$bin_path"
    done

    chmod +x "$bin_path"

    # Pack the binary with UPX
    (
        echo "Packing binary with UPX..."
        upx --force -o "$output_path" "$bin_path"
        local upx_result=$?

        # Modify the UPX header if a magic number is provided
        if [ -n "$magic_number" ]; then
            printf "$magic_number" | xxd -r -p >> "$output_path"
        fi

        # Capture UPX output and result
        echo "UPX exit code: $upx_result" >> "$output_file"
    ) >> "$output_file" 2>&1

    # Check if UPX operation was successful
    if [ $? -ne 0 ]; then
        echo "Error: Failed to create and pack binary $bin_path"
        return 1
    fi

    return 0
}

# Function to run a test with the packed binary
run_test() {
    local packed_bin="$1"
    local output_dir="./Linux_output/Defence_Evasion"
    local output_file="$output_dir/T1027.002_output.txt"

    # Ensure the output directory exists
    mkdir -p "$output_dir"

    # Run the test
    (
        echo "Running test for $packed_bin ..."
        cp "$packed_bin" /tmp/packed_bin && /tmp/packed_bin
        local test_result=$?

        # Cleanup
        echo "Cleaning up..."
        rm -f /tmp/packed_bin
        echo "Cleanup completed."

        exit $test_result
    ) >> "$output_file" 2>&1

    local test_result=$?

    # Display executed and completed message in the terminal
    if [ $test_result -eq 0 ]; then
        echo "Test for $packed_bin executed and completed successfully."
    else
        echo "Error: Test for $packed_bin failed with error code $test_result"
    fi

    return $test_result
}

# SISA Test #1 - Binary simply packed by UPX
bin_path="/tmp/test_upx"
create_and_pack_binary "$bin_path"

# Run SISA Test #1
run_test "$bin_path"
test_result=$?
if [ $test_result -ne 0 ]; then
    echo "Error: Test for $bin_path failed with error code $test_result"
    exit 1
fi

# SISA Test #2 - Binary packed by UPX, with modified headers
bin_path="/tmp/test_upx_header_changed"
magic_number="4c4f5452"  # HEX for "LOTR"
create_and_pack_binary "$bin_path" "$magic_number"

# Run SISA Test #2
run_test "$bin_path"
test_result=$?
if [ $test_result -ne 0 ]; then
    echo "Error: Test for $bin_path failed with error code $test_result"
    exit 1
fi

echo "All tests completed."
