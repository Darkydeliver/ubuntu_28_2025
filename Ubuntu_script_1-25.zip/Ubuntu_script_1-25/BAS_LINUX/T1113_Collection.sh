#!/bin/bash

# Define the output directories and files
output_dir="Linux_output/Collection"
output_file="${output_dir}/T1113_Collection.txt"
screenshot_dir="${output_dir}/T1113_Collection_screenshots"

# Create the output directories if they don't exist
mkdir -p "$output_dir"
mkdir -p "$screenshot_dir"

# Function to run a test and log its output
run_test() {
    description="$1"
    command="$2"
    
    echo "Running test: $description" | tee -a "$output_file"
    eval "$command" | tee -a "$output_file"
    echo "Test $description completed." | tee -a "$output_file"
    echo "---------------------------------------------" | tee -a "$output_file"
}

# Function to check and install a package if not present
check_and_install() {
    package_checker="$1"
    package_installer="$2"
    package_name="$3"
    
    echo "Checking for package: $package_name" | tee -a "$output_file"
    if eval "$package_checker" &>/dev/null; then
        echo "$package_name is already installed." | tee -a "$output_file"
    else
        echo "$package_name is not installed. Installing..." | tee -a "$output_file"
        eval "$package_installer" | tee -a "$output_file"
    fi
    echo "---------------------------------------------" | tee -a "$output_file"
}

# Tests

# SISA Test #3 - X Windows Capture
check_and_install "dpkg -s x11-apps" "sudo apt-get install -y x11-apps" "x11-apps"
run_test "X Windows Capture" "
xwd_output_file='${screenshot_dir}/T1113_desktop.xwd'
xwd -root -out \$xwd_output_file
xwud -in \$xwd_output_file
"

# SISA Test #4 - X Windows Capture (FreeBSD)
check_and_install "pkg info xwd" "sudo pkg install -y xwd xwud" "xwd and xwud"
run_test "X Windows Capture (FreeBSD)" "
xwd_output_file='${screenshot_dir}/T1113_desktop_freebsd.xwd'
xwd -root -out \$xwd_output_file
xwud -in \$xwd_output_file
"

# SISA Test #5 - Capture Linux Desktop using Import Tool
check_and_install "dpkg -s graphicsmagick-imagemagick-compat" "sudo apt-get install -y graphicsmagick-imagemagick-compat" "ImageMagick"
run_test "Capture Linux Desktop using Import Tool" "
import_output_file='${screenshot_dir}/T1113_desktop.png'
import -window root \$import_output_file
"

# SISA Test #6 - Capture Linux Desktop using Import Tool (FreeBSD)
check_and_install "pkg info ImageMagick7" "sudo pkg install -y ImageMagick7" "ImageMagick"
run_test "Capture Linux Desktop using Import Tool (FreeBSD)" "
import_output_file='${screenshot_dir}/T1113_desktop_freebsd.png'
import -window root \$import_output_file
"

# End of script
echo "All tests completed." | tee -a "$output_file"
echo "Execution completed. Output saved to ${output_file} and screenshots saved to ${screenshot_dir}"
