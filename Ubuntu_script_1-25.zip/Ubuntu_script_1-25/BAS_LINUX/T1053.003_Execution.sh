#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Execution"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1053.003_Execution.txt"

# Function to add timestamp to messages
timestamp() {
    date +"%Y-%m-%d %H:%M:%S"
}

{
    echo "===== SISA Test Execution Started at $(timestamp) ====="
    echo

    # SISA Test #1 - Replace crontab with referenced file
    echo "$(timestamp) - Starting SISA Test #1: Replace crontab with referenced file"
    command_SISA_1="/tmp/evil.sh"
    tmp_cron_SISA_1="/tmp/persistevil"

    # Backup current crontab as root
    sudo crontab -l > /tmp/notevil
    if [ $? -eq 0 ]; then
        echo "$(timestamp) - Current crontab backed up successfully."
    else
        echo "$(timestamp) - Failed to backup current crontab."
    fi

    # Replace crontab with new command as root
    echo "* * * * * $command_SISA_1" | sudo tee $tmp_cron_SISA_1 > /dev/null
    sudo crontab $tmp_cron_SISA_1
    if [ $? -eq 0 ]; then
        echo "$(timestamp) - Crontab replaced with new command successfully."
    else
        echo "$(timestamp) - Failed to replace crontab with new command."
    fi

    echo "$(timestamp) - SISA Test #1 executed successfully."
    echo

    # SISA Test #2 - Add script to all cron subfolders
    echo "$(timestamp) - Starting SISA Test #2: Add script to all cron subfolders"
    command_SISA_2="echo 'Hello from SISA Team' > /tmp/SISA.log"
    cron_script_name_SISA_2="persistevil"

    # Add script to cron folders as root
    echo "$command_SISA_2" | sudo tee /etc/cron.daily/$cron_script_name_SISA_2 > /dev/null
    echo "$command_SISA_2" | sudo tee /etc/cron.hourly/$cron_script_name_SISA_2 > /dev/null
    echo "$command_SISA_2" | sudo tee /etc/cron.monthly/$cron_script_name_SISA_2 > /dev/null
    echo "$command_SISA_2" | sudo tee /etc/cron.weekly/$cron_script_name_SISA_2 > /dev/null

    if [ $? -eq 0 ]; then
        echo "$(timestamp) - Script added to all cron subfolders successfully."
    else
        echo "$(timestamp) - Failed to add script to all cron subfolders."
    fi

    echo "$(timestamp) - SISA Test #2 executed successfully."
    echo

    # SISA Test #3 - Add script to /etc/cron.d folder
    echo "$(timestamp) - Starting SISA Test #3: Add script to /etc/cron.d folder"
    command_SISA_3="echo '*/5 * * * * root echo \"Hello from SISA Team\"' > /tmp/SISA.log"
    cron_script_name_SISA_3="persistevil"

    # Add script to /etc/cron.d folder as root
    echo "$command_SISA_3" | sudo tee /etc/cron.d/$cron_script_name_SISA_3 > /dev/null
    if [ $? -eq 0 ]; then
        echo "$(timestamp) - Script added to /etc/cron.d folder successfully."
    else
        echo "$(timestamp) - Failed to add script to /etc/cron.d folder."
    fi

    echo "$(timestamp) - SISA Test #3 executed successfully."
    echo

    # SISA Test #4 - Add script to /var/spool/cron/crontabs/ folder
    echo "$(timestamp) - Starting SISA Test #4: Add script to /var/spool/cron/crontabs folder"
    command_SISA_4="echo 'Hello from SISA Team' > /tmp/SISA.log"
    cron_script_name_SISA_4="persistevil"

    # Add script to /var/spool/cron/crontabs folder as root
    echo "$command_SISA_4" | sudo tee -a /var/spool/cron/crontabs/$cron_script_name_SISA_4 > /dev/null
    if [ $? -eq 0 ]; then
        echo "$(timestamp) - Script added to /var/spool/cron/crontabs folder successfully."
    else
        echo "$(timestamp) - Failed to add script to /var/spool/cron/crontabs folder."
    fi

    echo "$(timestamp) - SISA Test #4 executed successfully."
    echo

    echo "$(timestamp) - All SISA Tests executed successfully."
    echo "===== SISA Test Execution Ended at $(timestamp) ====="
} > "$output_file" 2>&1

echo "Execution completed. Output saved to $output_file"
