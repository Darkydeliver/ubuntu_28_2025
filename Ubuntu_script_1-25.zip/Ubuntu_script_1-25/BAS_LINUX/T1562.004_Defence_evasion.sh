#!/bin/bash

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check if UFW is installed and active
check_ufw() {
    if ! command_exists ufw; then
        echo -e "\n***** ufw NOT installed *****\n"
        exit 1
    fi
    if ufw status | grep -q "inactive"; then
        echo -e "\n***** ufw inactive *****\n"
        exit 1
    fi
}

# Function to check if pfctl is installed and active
check_pf() {
    if ! command_exists pfctl; then
        echo -e "\n***** PF NOT installed *****\n"
        exit 1
    fi
    if [ "$(kldstat -n pf)" = "" ]; then
        echo -e "\n***** PF inactive *****\n"
        exit 1
    fi
}

# Function to check if iptables is installed
check_iptables() {
    if ! command_exists iptables; then
        echo -e "\n***** iptables NOT installed *****\n"
        exit 1
    fi
}

# SISA Test #7 - Stop/Start UFW firewall
test_ufw_stop_start() {
    check_ufw
    echo "Stopping UFW firewall..."
    ufw disable
    echo "Cleanup: Starting UFW firewall..."
    ufw enable
    ufw status verbose
}

# SISA Test #8 - Stop/Start Packet Filter
test_pf_stop_start() {
    check_pf
    echo "Stopping Packet Filter..."
    service pf stop
    service pf disable
    echo "Cleanup: Starting Packet Filter..."
    service pf enable
    service pf start
    service pf status
}

# SISA Test #9 - Stop/Start UFW firewall using systemctl
test_ufw_systemctl() {
    if ! command_exists systemctl; then
        echo -e "\n***** systemctl NOT installed *****\n"
        exit 1
    fi
    check_ufw
    echo "Stopping UFW firewall using systemctl..."
    systemctl stop ufw
    echo "Cleanup: Starting UFW firewall using systemctl..."
    systemctl start ufw
    systemctl status ufw
}

# SISA Test #10 - Turn off UFW logging
test_ufw_logging_off() {
    check_ufw
    echo "Turning off UFW logging..."
    ufw logging off
    echo "Cleanup: Turning UFW logging to low..."
    ufw logging low
    ufw status verbose
}

# SISA Test #11 - Add and delete UFW firewall rules
test_ufw_add_delete_rules() {
    check_ufw
    echo "Adding UFW firewall rule..."
    ufw prepend deny from 1.2.3.4
    ufw status numbered
    echo "Cleanup: Deleting UFW firewall rule..."
    { echo y; echo response; } | ufw delete 1
    ufw status numbered
}

# SISA Test #12 - Add and delete Packet Filter rules
test_pf_add_delete_rules() {
    check_pf
    echo "Adding Packet Filter rule..."
    echo "block in proto tcp from 1.2.3.4 to any" | pfctl -a pf-rules -f -
    pfctl -a pf-rules -s rules
    echo "Cleanup: Deleting Packet Filter rule..."
    pfctl -a pf-rules -F rules
    sed -i "" '/anchor pf-rules/d'
    pfctl -f /etc/pf.conf
}

# SISA Test #13 - Edit UFW firewall user.rules file
test_edit_ufw_user_rules() {
    check_ufw
    echo "Editing UFW user.rules file..."
    echo "# THIS IS A COMMENT" >> /etc/ufw/user.rules
    grep "# THIS IS A COMMENT" /etc/ufw/user.rules
    echo "Cleanup: Removing comment from UFW user.rules file..."
    sed -i 's/# THIS IS A COMMENT//g' /etc/ufw/user.rules
}

# SISA Test #14 - Edit UFW firewall ufw.conf file
test_edit_ufw_conf() {
    if [ ! -f "/etc/ufw/ufw.conf" ]; then
        echo -e "\n***** /etc/ufw/ufw.conf NOT found *****\n"
        exit 1
    fi
    echo "Editing UFW ufw.conf file..."
    echo "# THIS IS A COMMENT" >> /etc/ufw/ufw.conf
    grep "# THIS IS A COMMENT" /etc/ufw/ufw.conf
    echo "Cleanup: Removing comment from UFW ufw.conf file..."
    sed -i 's/# THIS IS A COMMENT//g' /etc/ufw/ufw.conf
    cat /etc/ufw/ufw.conf
}

# SISA Test #15 - Edit UFW firewall sysctl.conf file
test_edit_ufw_sysctl_conf() {
    if [ ! -f "/etc/ufw/sysctl.conf" ]; then
        echo -e "\n***** /etc/ufw/sysctl.conf NOT found *****\n"
        exit 1
    fi
    echo "Editing UFW sysctl.conf file..."
    echo "# THIS IS A COMMENT" >> /etc/ufw/sysctl.conf
    grep "# THIS IS A COMMENT" /etc/ufw/sysctl.conf
    echo "Cleanup: Removing comment from UFW sysctl.conf file..."
    sed -i 's/# THIS IS A COMMENT//g' /etc/ufw/sysctl.conf
    cat /etc/ufw/sysctl.conf
}

# SISA Test #16 - Edit UFW firewall main configuration file
test_edit_ufw_main_conf() {
    if [ ! -f "/etc/default/ufw" ]; then
        echo -e "\n***** /etc/default/ufw NOT found *****\n"
        exit 1
    fi
    echo "Editing UFW main configuration file..."
    echo "# THIS IS A COMMENT" >> /etc/default/ufw
    grep "# THIS IS A COMMENT" /etc/default/ufw
    echo "Cleanup: Removing comment from UFW main configuration file..."
    sed -i 's/# THIS IS A COMMENT//g' /etc/default/ufw
}

# SISA Test #17 - Tail the UFW firewall log file
test_tail_ufw_log() {
    if [ ! -f "/var/log/ufw.log" ]; then
        echo -e "\n***** /var/log/ufw.log NOT found *****\n"
        exit 1
    fi
    echo "Tailing UFW log file..."
    tail /var/log/ufw.log
}

# SISA Test #18 - Disable iptables
test_disable_iptables() {
    check_iptables
    echo "Disabling iptables..."
    iptables-save > /tmp/iptables.rules
    iptables -F
    echo "Cleanup: Restoring iptables rules..."
    iptables-restore < /tmp/iptables.rules
}

# SISA Test #19 - Modify/delete iptables firewall rules
test_modify_delete_iptables() {
    check_iptables
    if ! iptables -L | grep -q "DROP .*dpt:ftp"; then
        echo -e "\n***** this firewall rule is NOT activated *****\n***** activate it by executing \"iptables -A OUTPUT -p tcp --dport 21 -j DROP\" *****\n"
        exit 1
    fi
    echo "Deleting iptables firewall rule..."
    iptables-save > /tmp/iptables.rules
    iptables -D OUTPUT -p tcp --dport 21 -j DROP
    echo "Cleanup: Restoring iptables rules..."
    iptables-restore < /tmp/iptables.rules
}

# Main script execution
main() {
    test_ufw_stop_start
    test_pf_stop_start
    test_ufw_systemctl
    test_ufw_logging_off
    test_ufw_add_delete_rules
    test_pf_add_delete_rules
    test_edit_ufw_user_rules
    test_edit_ufw_conf
    test_edit_ufw_sysctl_conf
    test_edit_ufw_main_conf
    test_tail_ufw_log
    test_disable_iptables
    test_modify_delete_iptables
    echo "All chosen SISA tests executed."
}

# Run the main function
main
