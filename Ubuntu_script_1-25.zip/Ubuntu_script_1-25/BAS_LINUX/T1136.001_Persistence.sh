#!/bin/bash

# Define the path for Linux_output directory
LinuxOutputDir="$(pwd)/Linux_output"

# Ensure Linux_output directory exists
mkdir -p "$LinuxOutputDir"

# Define the path for Persistence directory
PathToAtomicsFolder="$LinuxOutputDir/Persistence"

# Ensure Persistence directory exists
mkdir -p "$PathToAtomicsFolder"

# Define the path for T1136.001_Persistence directory
AtomicFolder="$PathToAtomicsFolder/T1136.001_Persistence"

# Ensure T1136.001_Persistence directory exists
mkdir -p "$AtomicFolder"

# Define output text file path
OutputLogFile="$AtomicFolder/T1136.001_Persistence.txt"

# Define default values for user creation
DEFAULT_USERNAME="evil_user"
DEFAULT_PASSWORD="BetterWithButter"

# Function to create a user on Linux using useradd
function create_linux_user {
    local username=$1
    echo "Creating user $username on Linux..." | tee -a "$OutputLogFile"
    sudo useradd -M -N -r -s /bin/bash -c "evil_account $username" "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        echo "Linux user $username created successfully." | tee -a "$OutputLogFile"
    else
        echo "Failed to create Linux user $username." | tee -a "$OutputLogFile"
    fi
}

# Function to clean up Linux user
function cleanup_linux_user {
    local username=$1
    echo "Cleaning up Linux user $username..." | tee -a "$OutputLogFile"
    sudo userdel "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        echo "Linux user $username deleted successfully." | tee -a "$OutputLogFile"
    else
        echo "Failed to delete Linux user $username." | tee -a "$OutputLogFile"
    fi
}

# Function to create a Linux user with root UID and GID
function create_linux_user_with_root_gid {
    local username=$1
    local password=$2
    echo "Creating Linux user $username with root UID and GID..." | tee -a "$OutputLogFile"
    sudo useradd -g 0 -M -d /root -s /bin/bash "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        echo "$username:$password" | sudo chpasswd
        echo "Linux user $username created and password set." | tee -a "$OutputLogFile"
    else
        echo "Failed to create Linux user $username." | tee -a "$OutputLogFile"
    fi
}

# Function to clean up Linux user with root UID and GID
function cleanup_linux_user_with_root_gid {
    local username=$1
    echo "Cleaning up Linux user $username with root UID and GID..." | tee -a "$OutputLogFile"
    sudo userdel "$username" &>> "$OutputLogFile"
    if [ $? -eq 0 ]; then
        echo "Linux user $username deleted successfully." | tee -a "$OutputLogFile"
    else
        echo "Failed to delete Linux user $username." | tee -a "$OutputLogFile"
    fi
}

# Main script logic
echo "Setting up and executing user creation tests..." | tee -a "$OutputLogFile"

# Execute Atomic Test #1: Create a user account on Linux
create_linux_user "$DEFAULT_USERNAME"
cleanup_linux_user "$DEFAULT_USERNAME"

# Execute Atomic Test #6: Create a new user in Linux with root UID and GID
create_linux_user_with_root_gid "butter" "$DEFAULT_PASSWORD"
cleanup_linux_user_with_root_gid "butter"

echo "All user creation tests executed." | tee -a "$OutputLogFile"
