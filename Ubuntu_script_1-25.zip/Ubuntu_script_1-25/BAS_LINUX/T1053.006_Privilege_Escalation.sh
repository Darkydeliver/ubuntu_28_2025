#!/bin/bash

# Function to create necessary folders and output file
setup_output_folder() {
    local output_folder="./Linux_output/Privilege_Escalation"
    mkdir -p "$output_folder"
    echo "Output folder created: $output_folder"

    local output_file="$output_folder/T1053.006_Privilege_Escalation.txt"
    touch "$output_file"
    echo "Output file created: $output_file"
}

# Function to create and manage Systemd service and timer
setup_systemd_service_and_timer() {
    local path_to_systemd_service="/etc/systemd/system/sisa-timer.service"
    local path_to_systemd_timer="/etc/systemd/system/sisa-timer.timer"
    local systemd_service_name="sisa-timer.service"
    local systemd_timer_name="sisa-timer.timer"

    # Create the systemd service file
    echo "[Unit]" | sudo tee $path_to_systemd_service > /dev/null
    echo "Description=SISA Systemd Timer Service for Privilege Escalation" | sudo tee -a $path_to_systemd_service > /dev/null
    echo "[Service]" | sudo tee -a $path_to_systemd_service > /dev/null
    echo "Type=simple" | sudo tee -a $path_to_systemd_service > /dev/null
    echo "ExecStart=/bin/touch /tmp/sisa-systemd-timer-marker" | sudo tee -a $path_to_systemd_service > /dev/null
    echo "[Install]" | sudo tee -a $path_to_systemd_service > /dev/null
    echo "WantedBy=multi-user.target" | sudo tee -a $path_to_systemd_service > /dev/null

    # Create the systemd timer file
    echo "[Unit]" | sudo tee $path_to_systemd_timer > /dev/null
    echo "Description=Executes SISA Systemd Timer Service for Privilege Escalation" | sudo tee -a $path_to_systemd_timer > /dev/null
    echo "Requires=$systemd_service_name" | sudo tee -a $path_to_systemd_timer > /dev/null
    echo "[Timer]" | sudo tee -a $path_to_systemd_timer > /dev/null
    echo "Unit=$systemd_service_name" | sudo tee -a $path_to_systemd_timer > /dev/null
    echo "OnCalendar=*-*-* *:*:00" | sudo tee -a $path_to_systemd_timer > /dev/null
    echo "[Install]" | sudo tee -a $path_to_systemd_timer > /dev/null
    echo "WantedBy=timers.target" | sudo tee -a $path_to_systemd_timer > /dev/null

    # Start and enable the systemd timer
    sudo systemctl start $systemd_timer_name
    sudo systemctl enable $systemd_timer_name
}

# Reload systemd daemon to apply changes
reload_systemd_daemon() {
    sudo systemctl daemon-reload
}

# Main script execution
echo "Starting execution..."
setup_output_folder
setup_systemd_service_and_timer
reload_systemd_daemon

# Redirect all output to the output file
{
    echo "SISA Systemd service and timer setup completed for Privilege Escalation."
    echo "Execution completed. All tests executed successfully."
} > "./Linux_output/Privilege_Escalation/T1053.006_Privilege_Escalation.txt"

echo "Output stored in ./Linux_output/Privilege_Escalation/T1053.006_Privilege_Escalation.txt"
