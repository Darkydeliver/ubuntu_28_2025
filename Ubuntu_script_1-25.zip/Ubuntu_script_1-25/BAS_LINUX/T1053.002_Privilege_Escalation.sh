#!/bin/bash

# Ensure the output directory exists
output_dir="Linux_output/Privilege_Escalation"
mkdir -p "${output_dir}"

# Define the output file path
output_file="${output_dir}/T1053.002_Privilege_Escalation.txt"

# Function to install 'at' if needed
install_at_if_needed() {
    if ! command -v at &> /dev/null; then
        echo "'at' command not found. Installing it..."
        if [ "$(uname)" = 'Linux' ]; then
            if command -v apt-get &> /dev/null; then
                sudo apt-get update
                sudo apt-get install -y at
            else
                echo "Error: Package manager 'apt-get' not found. Manual installation of 'at' required."
                exit 1
            fi
        else
            echo "Error: Unsupported platform. Manual installation of 'at' required."
            exit 1
        fi

        if ! command -v at &> /dev/null; then
            echo "Failed to install 'at'. Please install it manually and try again."
            exit 1
        else
            echo "'at' installed successfully."
        fi
    else
        echo "'at' command found."
    fi
}

# Function to schedule a job using 'at'
schedule_job() {
    time_spec="now + 1 minute"
    at_command="echo Hello from SISA Team"
    
    echo "${at_command}" | at ${time_spec}
}

# Function to clean up the scheduled job
cleanup_job() {
    job_id=$(atq | awk '{print $1}')
    if [ -n "${job_id}" ]; then
        atrm "${job_id}"
        echo "Scheduled job ${job_id} removed."
    else
        echo "No jobs found in the at queue to remove."
    fi
}

# Main script execution

# Redirect all output to the specified file and also display it in the terminal
{
    echo "Script execution started at $(date)"
    echo
    
    install_at_if_needed
    schedule_job

    # Wait for 10 seconds to allow job scheduling
    sleep 10

    # Verify and cleanup
    cleanup_job
    
    echo
    echo "Script execution complete at $(date). Output saved to: ${output_file}"
} | tee "${output_file}"


